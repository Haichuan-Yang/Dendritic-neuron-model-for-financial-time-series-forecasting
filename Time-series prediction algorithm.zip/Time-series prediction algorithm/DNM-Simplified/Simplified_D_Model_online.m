function [O,Error,E,w,q]=Simplified_D_Model_online(InputData,TeacherData,parameters)

[I,J]=size(InputData);
ita = parameters(3); % Leanring rate ita
k = parameters(1);
qs = parameters(2);
MaxEpoch = parameters(4);

%%%%%%%%%%%%%%%%%%%%%%% 
%inialize the parameters in the model
% w=4*(rand(1,I)-1/2);
% q=4*(rand(1,I)-1/2);
w=2*(rand(1,I)-1/2);
q=2*(rand(1,I)-1/2);
Y=zeros(I,J);
U=ones(1,J);
O=zeros(J,MaxEpoch);
E=zeros(J,MaxEpoch);

dEO=zeros(1,J);
dOU=zeros(1,J);
dUY=zeros(1,J);
dYw=zeros(I,J);
dYq=zeros(I,J);

dEw=zeros(I,J);
dEq=zeros(I,J);
%%%%%%%%%%%%%%%%%%%%%%%

% bulid Single Dendritic Neuron Model
for e=1:MaxEpoch 
%  disp(['-- Epoch: ', num2str(e), ' --']);
    
 Sample=randperm(J);  
% build a connection layer
 for j=1:J
     for i=1:I
         Y(i,Sample(j))=w(i)*InputData(i,Sample(j)) + q(i);
     end
     
     temp=1;
     for i=1:I
         temp = temp * Y(i,Sample(j));
     end
     U(Sample(j)) = temp;
     
     O(Sample(j),e)=1/(1+exp(-k*(U(Sample(j))- qs))); 
     
     E(Sample(j),e) = 1/2*((O(Sample(j),e) - TeacherData(Sample(j)))^2);

    %BackPropagation-like Learning Algorithm
    dEO(Sample(j))=O(Sample(j),e)-TeacherData(Sample(j));
    dOU(Sample(j))=k*exp(-k*(U(Sample(j))-qs))/(1+ exp(-k*(U(Sample(j))-qs)))^2;
    for i=1:I
       temp1=1;
       for LL=1:I
           if(LL~=i) 
               temp1=temp1*Y(LL,Sample(j)); 
           end
       end   
       dUY(i,Sample(j)) = temp1;
       dYw(i,Sample(j)) = InputData(i,Sample(j));
       dYq(i,Sample(j)) = 1; 
       
       dEw(i,Sample(j)) = dEO(Sample(j))*dOU(Sample(j))*dUY(i,Sample(j))*dYw(i,Sample(j));
       dEq(i,Sample(j)) = dEO(Sample(j))*dOU(Sample(j))*dUY(i,Sample(j))*dYq(i,Sample(j));
       
       w(i)=w(i) - ita*dEw(i,Sample(j));
       q(i)=q(i) - ita*dEq(i,Sample(j));
    end
    
  end
  
  %Show the final output
  
end
Error=1/J*sum(E)*2;