function [O,Error,E]=Simplified_D_Model_Prediction(testdata,targetdata,w,q,parameters)

    k = parameters(1);
    qs = parameters(2);
    [I,J] = size(testdata);
    Y = zeros(I,J);
    U = ones(1,J);
    O = zeros(1,J);
    E = zeros(1,J);

     for j=1:J
         for i=1:I
             Y(i,j)=w(i)*testdata(i,j) + q(i);
         end

         temp=1;
         for i=1:I
             temp = temp * Y(i,j);
         end
         U(j) = temp;

         O(j)=1/(1+exp(-k* (U(j)- qs) )); 

         E(j) = 1/2*((O(j) - targetdata(j))^2);

     end

     Error=1/J*sum(E)*2;
     %Error=sum(E);
end