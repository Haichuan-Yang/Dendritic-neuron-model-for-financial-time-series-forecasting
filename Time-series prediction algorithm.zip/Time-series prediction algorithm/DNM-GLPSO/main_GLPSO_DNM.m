function [w,q,optimal,out] = main_GLPSO_DNM(Parameter,net,train_data,train_target)
optimal=[];
optimalChart_interval = Parameter.optimalChart_interval;
D = Parameter.D;
l_value=0.5;
M = net.M1;
[~,J] =size(train_data); % J: the dimension of samples
nFES = 0;
iter = 0;
addpath('../');
optimalChart = [];
ProblemSize = D;

popuSize = Parameter.popsize;
FES = Parameter.FES;

% initial population人口初始0化
lu = [-10* ones(1, D); 10* ones(1, D)];
popu = repmat(lu(1, :), popuSize, 1) + rand(popuSize, D) .* (repmat(lu(2, :) - lu(1, :), popuSize, 1));

popuFitness = zeros(popuSize,1);
for popindex = 1:popuSize
    w = popu(popindex,1:J*M);
    q = popu(popindex,J*M+1:D);
    w = reshape(w,J,M);
    q = reshape(q,J,M);
    net.w = w;
    net.q = q;
    train_fit = my_DNM(train_data,net);
    cost = (train_fit - train_target).^2;
    popuFitness(popindex) = mean(cost);
end
optimal = min(popuFitness);
        vel = zeros(popuSize, D);
        pBest = popu;
        pBestFit = popuFitness;
        [gBestFit, gBestId] = min(pBestFit);
        gBest = pBest(gBestId,:);
        omega = 0.7298;
        c = 1.49618;
        flag = zeros(popuSize,1);
        sg = 7;
        pm = 0.01;
        nFES = nFES + popuSize;

  %==========================================================================
   while nFES <= FES
             for i = 1:popuSize
                %% Exemplar Update: Crossover
                offsPbest = zeros(1,D);
                for d = 1:D
                    k = randperm(popuSize,1);
                    if pBestFit(i) < pBest(k)
                        r = rand;
                        offsPbest(d) = r * pBest(i,d) + (1 - r) * gBest(1,d);
                    else
                        offsPbest(d) = pBest(k,d);
                    end
                end
                %% Exemplar Update: Mutation
                for d = 1:D
                    if rand < pm
                        offsPbest(d) = lu(1,d) + rand * (lu(2,d) - lu(1,d));
                    end
                end
                %% Exemplar Update: Selection
                for popindex = 1:1
                    w = offsPbest(popindex,1:J*M);
                    q = offsPbest(popindex,J*M+1:D);
                    w = reshape(w,J,M);
                    q = reshape(q,J,M);
                    net.w = w;
                    net.q = q;
                    train_fit = my_DNM(train_data,net);
                    cost = (train_fit - train_target).^2;
                    offsPbestFitness(popindex) = mean(cost);
                end

                nFES = nFES + 1;
                if offsPbestFitness < optimal
                    optimal = offsPbestFitness;
                end
                optimalChart = [optimalChart;optimal];
                
                if offsPbestFitness < pBestFit(i)
                    pBest(i,:) = offsPbest;
                    pBestFit(i) = offsPbestFitness;
                end
                %% 20%M tournament
                if flag(i) == sg
                    flag(i) = 0;
                    competitor = randperm(popuSize, 0.2 * popuSize);
                    [winner, winId] = min(pBestFit(competitor));
                    pBest(i,:) = pBest(competitor(winId),:);
                    pBestFit(i) = pBestFit(competitor(winId));
                end
                
                %% Particle Update
                for d = 1:D
                    vel(i,d) = omega * vel(i,d) + c * rand * (pBest(i,d) - popu(i,d));
                    popu(i,d) = popu(i,d) + vel(i,d);
                end
            end
            %% Boundary detection
            [popu] = BoundaryDetection(popu,lu);
            
            %% Evaluatition

            for popindex = 1:popuSize
                w = popu(popindex,1:J*M);
                q = popu(popindex,J*M+1:D);
                w = reshape(w,J,M);
                q = reshape(q,J,M);
                net.w = w;
                net.q = q;
                train_fit = my_DNM(train_data,net);
                cost = (train_fit - train_target).^2;
                popuFitness(popindex,:) = mean(cost);
            end


            if min(popuFitness) < optimal
                optimal = min(popuFitness);
            end
            nFES = nFES + popuSize;
            optimalChart = [optimalChart;repmat(optimal,popuSize,1)];
            %% Update pBest
            pos = popuFitness < pBestFit;
            flag(~pos) = flag(~pos) + 1;
            pBestFit(pos) = popuFitness(pos);
            pBest(pos,:) = popu(pos,:);
            [gBestFit, gBestId] = min(pBestFit);
            gBest = pBest(gBestId,:);

   end
 
    w = gBest(1:J*M);
    q = gBest(J*M+1:ProblemSize);
    w=reshape(w,J,M);
    q=reshape(q,J,M);
end