function [w,q,optimal,out] = main_SASS_DNM(Parameter,net,train_data,train_target)
optimal=[];
optimalChart_interval = Parameter.optimalChart_interval;
D = Parameter.D;
l_value=0.5;
M = net.M1;
[~,J] =size(train_data); % J: the dimension of samples
nFES = 0;
iter = 0;
addpath('../');
optimalChart = [];
ProblemSize = D;
n=D;
PopSize = Parameter.popsize;
FES = Parameter.FES;

% initial population人口初始0化
lu = [-10* ones(1, D); 10* ones(1, D)];
popu = repmat(lu(1, :), PopSize, 1) + rand(PopSize, D) .* (repmat(lu(2, :) - lu(1, :), PopSize, 1));
popu2 = popu;
x_selected= popu;
constraints=lu';
% 弶巒壔??搙
N = PopSize;
step= [];
N0 = floor((N)^(1/n));	% number of points in regular grid per one dimension
for i = 1:n
    step(i) = (constraints(i,2)-constraints(i,1))/N0;
end

% discretization step
delta_x_m = step;

Fitness = zeros(PopSize,1);
for popindex = 1:PopSize
    w = popu(popindex,1:J*M);
    q = popu(popindex,J*M+1:D);
    w = reshape(w,J,M);
    q = reshape(q,J,M);
    net.w = w;
    net.q = q;
    train_fit = my_DNM(train_data,net);
    cost = (train_fit - train_target).^2;
    Fitness(popindex) = mean(cost);
    AFitness = Fitness;
end
[AllFitnessSorted,IndexSorted] = sort(Fitness);
gBestFit = 1e+30;
best_population = zeros(1, ProblemSize);
    for i = 1 : PopSize
        nFES = nFES + 1;
        if Fitness(i) < gBestFit
            gBestFit = Fitness(i);
            best_population = popu(i, :);
        end
        if mod(nFES, optimalChart_interval) == 0
            optimalChart = [optimalChart;gBestFit];
        else
            if nFES == FES
                optimalChart = [optimalChart;gBestFit];
            end
        end
        %             optimalChart = [optimalChart;gBestFit];
        if nFES >= FES; break; end
    end
  %==========================================================================
   while nFES <= FES
            iter = iter + 1;

            R=nFES/FES*0.1;

            f_temp = [];

            c=floor(PopSize*l_value);
            cc=PopSize-c;


            x_sele1=zeros(c, n);
            Chaos=[];
            z1=rand(n,1);
            for s=1:n
                while z1(s)==0.25 || z1(s)==0.5 || z1(s)==0.75
                    z1(s)=rand;
                end
            end
            a=4.0;
            Chaos(:,1)=z1;
            for h=1:c-1
                Chaos(:,h+1)=a*Chaos(:,h)-Chaos(:,h)*a.*Chaos(:,h);
            end
            neighborhood =Chaos';
            for i = 1:c
                x= x_selected(IndexSorted(floor(1*rand)+1),:);
                for j = 1:n
                    x_sele1(i,j) = (2*neighborhood(i,j)-1)*delta_x_m(1,j)+...
                        x(1,j)*ones(1,1);
                end
            end
            [x_sele1] = BoundaryDetection(x_sele1,lu);
            for popindex = 1:c
                w = x_sele1(popindex,1:J*M);
                q = x_sele1(popindex,J*M+1:D);
                w=reshape(w,J,M);
                q=reshape(q,J,M);
                net.w = w;
                net.q = q;
                train_fit = my_DNM(train_data,net);
                cost = (train_fit - train_target).^2;
                fl(popindex) = mean(cost);
            end
            [optimalFitl,optIl] = min(fl);
            ffl=optimalFitl;

            x_sele2=zeros(cc, n);
            neighborhoodc =rand(cc, n);
            for i = 1:cc
                x= x_selected(IndexSorted(floor(1*rand)+1),:);
                for j = 1:n
                    x_sele2(i,j) = (2*neighborhoodc(i,j)-1)*delta_x_m(1,j)+...
                        x(1,j)*ones(1,1);
                end
            end
            [x_sele2] = BoundaryDetection(x_sele2,lu);
            for popindex = 1:cc
                w = x_sele2(popindex,1:J*M);
                q = x_sele2(popindex,J*M+1:D);
                w=reshape(w,J,M);
                q=reshape(q,J,M);
                net.w = w;
                net.q = q;
                train_fit = my_DNM(train_data,net);
                cost = (train_fit - train_target).^2;
                fc(popindex) = mean(cost);
            end
            [optimalFitc,optIc] = min(fc);
            ffc=optimalFitc;
            x_selected= [[]; x_sele1; x_sele2];
            f_temp = [f_temp, fl, fc];
            f_temp= f_temp';
            Fitness =  f_temp;    % all values: old and new
            [AllFitnessSorted,IndexSorted] = sort(Fitness);

            
            if ffc<ffl
                delta_x_m=delta_x_m-R*delta_x_m;
            else
                delta_x_m=delta_x_m+R*delta_x_m;
            end


%             for i=1:5
%                 randPopuList = randperm(PopSize);
%                 randPopuList = setdiff(randPopuList,1,'stable');
%                 indiR1 = popu2(randPopuList(1),:);
%                 indiR2 = popu2(randPopuList(2),:);
%                 x= x_selected(IndexSorted(i),:);
%                 temp_X=x+(indiR1-indiR2)*rand*1;%r=0.1
%                 nFES=nFES+1;
%                 [temp_X] = BoundaryDetection(temp_X,lu);
% 
%                 w = temp_X(1:J*M);
%                 q = temp_X(J*M+1:D);
%                 w=reshape(w,J,M);
%                 q=reshape(q,J,M);
%                 net.w = w;
%                 net.q = q;
%                 train_fit = my_DNM(train_data,net);
%                 cost = (train_fit - train_target).^2;
%                 fit_temp = mean(cost);
% 
% 
%                 fit_temp=fit_temp';
%                 if fit_temp<=AllFitnessSorted(i)
%                     x_selected(IndexSorted(i),:)=temp_X;
%                     if mod(nFES, optimalChart_interval) == 0
%                         optimalChart = [optimalChart;fit_temp];
%                     end
%                 else
%                     if mod(nFES, optimalChart_interval) == 0
%                         optimalChart = [optimalChart;AllFitnessSorted(1)];
%                     end
%                 end
%                 [biggFit,I] = max(AFitness);
%                 if fit_temp<biggFit
%                     popu2(I,:)=temp_X;
%                     AFitness(I)=fit_temp;
%                 end
%             end

            for i = 1 : PopSize
                nFES = nFES + 1;
                if Fitness(i) < gBestFit
                    gBestFit = Fitness(i);
                    best_population=x_selected(i,:);
                end
                if mod(nFES, optimalChart_interval) == 0
                    optimalChart = [optimalChart;gBestFit];
                else
                    if nFES == FES
                        optimalChart = [optimalChart;gBestFit];
                    end
                end
                if nFES > FES; break; end
            end
   end

  
    
    w = best_population(1:J*M);
    q = best_population(J*M+1:ProblemSize);
    w=reshape(w,J,M);
    q=reshape(q,J,M);
end