x=[-2:0.1:2];
w=-4;
q=2;
y=1./(1+exp(-(w*x-q)));
plot(x,y,'linewidth',1.5);