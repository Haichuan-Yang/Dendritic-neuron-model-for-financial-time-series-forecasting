% Main PSR

data = original;

[tau,I_Sq] = mutual_information(data); % Mutuai Information for time delay
[ln_r,ln_C,Y] = G_P_good(data,tau); % G-P for embedding dimension
GPployfit(ln_r, ln_C);

