function [net per train_ty test_ty Error_prediction] = MLP(trainx1, trainy1, testx1,target, parameters,st2)
%% Construct MLP
net = feedforwardnet(parameters(1),'traingd');
net.trainparam.lr=parameters(3);
net.trainParam.epochs=parameters(4);
net.trainParam.goal=0.00001;
net.trainParam.max_fail=5;
net.divideParam.trainRatio=1;
net.divideParam.valRatio=0;
net.divideParam.testRatio=0;
net=init(net);

%% Network Training
[net,per] = train(net,trainx1,trainy1);

%% Network Testing and Prediction
train_ty1 = sim(net, trainx1);
train_ty = mapminmax('reverse', train_ty1, st2);
test_ty1 = sim(net, testx1);
test_ty = mapminmax('reverse', test_ty1, st2);

%%
J=length(target);
for j=1:J
    Error(j)=(test_ty1(j)-target(j))^2;
end
Error_prediction=1/J*sum(Error);
end