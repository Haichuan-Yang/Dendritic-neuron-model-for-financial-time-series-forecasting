% ============================= %
% Modified Version of Yarpiz's ANFIS
% Using genfis fuctions suggested by Matlab Documents
% Developed by Haichuan Yang (0000-0001-7100-7945) 2022.12
% Run Main_Elman for all data
% ============================= %

clear all;
name = ["DJIA-90","NASDAQCOM-90", "NDX100-90", "NIKKEI225-90", "SP500-90"];
tic


% Choose Model
ModelNumber = 7;    % 1.DNM+PSR  2.Simplified DNM 3.Elman Network 4.MLP Network  5.DNM-BP
% 6.DNM-SIS  7.DNM-SHADE  8.DNM-DE  9.DNM-GLPSO 10.DNM-JADE 11.DNM-SE
switch ModelNumber
    case {1,2}
        parameters=[5 0 0.01 1000]; % k qs ita MaxEpoch
    case 3
        parameters=[15 0.01 1000]; % M ita epoch
    case 4
        parameters=[15 1 0.1 1000]; % M ita epoch
    case 5
        parameters=[5 1 10 0.1 1000]; % k qs M ita MaxEpoch
    case {6,7,8,9,10,11}
        parameters=[5 1 10 0.1 1000]; % k qs M ita MaxEpoch
end
for nm=1:length(name)
    XX=[];
    for time=1:30
        % Data Load and Divide
        load (name(nm))
        m = 2; % embedding dimension (using m-1 to predict)
        tau = 1; % time delay

        N = length(original)-1; % data length to reconstruct, -1 for the last element not in the PSR matrix.
        M = N-(m-1)*tau; % PSR matrix data length
        Boundary = round(0.7*M); % trainning data length
        n = M-Boundary; % testing data length

        PSR_matrix = zeros(m,M); % construct PSR matrix
        for i=1:m
            PSR_matrix(i,:) = original((1+(i-1)*tau):(M+(i-1)*tau));
        end
        PSR_target = original(N-M+2:end);
        trainx = PSR_matrix(1:m,1:Boundary);
        trainy = PSR_target(1:Boundary);
        testx = PSR_matrix(1:m,Boundary+1:M);
        testy = PSR_target(Boundary+1:M);

        % Data normalization
        [trainx_normalized,st1] = mapminmax(trainx,0,1);
        [trainy_normalized,st2] = mapminmax(trainy,0,1);
        testx_normalized = mapminmax('apply',testx,st1);
        testy_normalized = mapminmax('apply',testy,st2);

        % Trainning
        switch ModelNumber
            case {1,2}
                [O,Error,E,w,q]=...,
                    Simplified_D_Model_online(trainx_normalized, trainy_normalized, parameters);
                trainy_predicated = mapminmax('reverse', O(:,parameters(4)), st2); % Output after MaxEpoch
            case 3 % For Elman Network, Training and Prediction are carried together
                [net per trainy_predicated testy_prediction Error_prediction]= Elman(trainx_normalized, trainy_normalized, testx_normalized,testy_normalized,parameters,st2);
                trainy_predicated=trainy_predicated';
            case 4 % For MLP, Training and Prediction are carried together
                [net per trainy_predicated testy_prediction Error_prediction]= MLP(trainx_normalized, trainy_normalized, testx_normalized,testy_normalized,parameters,st2);
                trainy_predicated=trainy_predicated';
            case 5
                [O,Error,E,w,q]=...,
                    D_Model_online(trainx_normalized, trainy_normalized, parameters);
                trainy_predicated = mapminmax('reverse', O(:,parameters(5)), st2); % Output after MaxEpoch
            case {6,7,8,9,10,11}
                qs=parameters(2);
                M1=parameters(3);
                k=parameters(1);
                time = 1;

                [I,J] = size(trainx_normalized');
                optimalChart_interval = 100;
                % D进化算法的维度 = ??据维度*DNM层??*2。 即种群作为阈值和权重信息
                D = J * M1 * 2;
                % parameter structure 参??结构将SASS放??DNM中
                net.M1 = M1;
                net.qs = qs;
                net.k = k;
                train_data=trainx_normalized';
                train_target=trainy_normalized';
                Parameter.optimalChart_interval = optimalChart_interval;
                Parameter.D = D;
                switch ModelNumber
                    case 6
                        popsize = 20;
                        FES = 50000;
                        Parameter.FES = FES;
                        Parameter.popsize = popsize;
                        [w,q,optimal] = main_SIS_DNM(Parameter,net,train_data,train_target) ;
                    case 7
                        popsize = 100;
                        FES = 40000;
                        Parameter.FES = FES;
                        Parameter.popsize = popsize;
                        [w,q,optimal] = main_SHADE_DNM(Parameter,net,train_data,train_target) ;
                    case 8
                        popsize = 100;
                        FES = 50000;
                        Parameter.FES = FES;
                        Parameter.popsize = popsize;
                        [w,q,optimal] = main_DE_DNM(Parameter,net,train_data,train_target) ;
                    case 9
                        popsize = 100;
                        FES = 50000;
                        Parameter.FES = FES;
                        Parameter.popsize = popsize;
                        [w,q,optimal] = main_GLPSO_DNM(Parameter,net,train_data,train_target) ;
                    case 10
                        popsize = 100;
                        FES = 50000;
                        Parameter.FES = FES;
                        Parameter.popsize = popsize;
                        [w,q,optimal] = main_JADE_DNM(Parameter,net,train_data,train_target) ;
                    case 11
                        popsize = 100;
                        FES = 50000;
                        Parameter.FES = FES;
                        Parameter.popsize = popsize;
                        [w,q,optimal] = main_SE_DNM(Parameter,net,train_data,train_target) ;
                end
                net.w = w;
                net.q = q;
                O=GETO(parameters,trainx_normalized,net);
                trainy_predicated = mapminmax('reverse', O(:,parameters(5)), st2); % Output after MaxEpoch

        end

        % Prediction
        switch ModelNumber
            case {1,2}
                [testy_prediction_nor, Error_prediction, E_prediction]= ...,
                    Simplified_D_Model_Prediction(testx_normalized, testy_normalized, w, q, parameters);
                testy_prediction = mapminmax('reverse', testy_prediction_nor, st2);
            case {5,6,7,8,9,10,11}
                [testy_prediction_nor, Error_prediction, E_prediction]=...,
                    D_Model_Prediction(testx_normalized, testy_normalized, w, q, parameters);
                testy_prediction = mapminmax('reverse', testy_prediction_nor, st2);
        end

        % Final Results
        final = [trainy_predicated',testy_prediction];

        % Error Calculation
        final_fit = final(1:Boundary);
        final_test = final(Boundary+1:M);
        original_fit = original(N-M+1:N-M+Boundary);
        original_test = original(N-M+Boundary+1:N);

        MSE = 1/n*sum((final_test - original_test).^2);
        MAPE = 1/n*sum(abs((original_test - final_test)/original_test));
        MAE = 1/n*sum(abs((original_test - final_test)));
        RMSE = MSE^0.5;
        R_fit = sum((original_fit-mean(original_fit)).*(final_fit-mean(final_fit)))/((sum((original_fit-mean(original_fit)).^2*sum((final_fit-mean(final_fit)).^2)))^0.5);
        R_pre = sum((original_test-mean(original_test)).*(final_test-mean(final_test)))/((sum((original_test-mean(original_test)).^2*sum((final_test-mean(final_test)).^2)))^0.5);

        disp(['MSE = ', num2str(MSE)])
        disp(['MAPE = ', num2str(MAPE)])
        disp(['MAE = ', num2str(MAE)])
        disp(['RMSE = ', num2str(RMSE)])
        disp(['R_fit = ', num2str(R_fit)])
        disp(['R_predict = ', num2str(R_pre)])

        X=[MSE,MAPE,MAE];
        XX=[XX;X];

        % Display the Fianl Results
        figure(1) % origin/result
        rawdata = original(N-M+1:N);
        newdata = final;
        x = 1:length(rawdata);
        x_bounary = length(trainy);
        plot(x,rawdata,'b-');
        hold on
        plot(x,newdata,'r--');
        hold on
        B=get(gca, 'YLim');
        plot([x_bounary, x_bounary], [B(1), B(2)], '--m');
        legend('Actual Value','Predictive Value','Location','NorthWest');
        title('Training and Prediction','FontName','Arial','FontWeight','Bold','FontSize',15);
        xlabel('Data Number','FontName','Arial','FontSize',12);
        ylabel('Value','FontName','Arial','FontSize',12);
        text('Position',[x_bounary*2/3,B(2)*5/6],'String','Training','color','r');
        text('Position',[x_bounary + 5,B(2)*5/6],'String','Prediction','color','r');
        hold off

        % figure(2) % regression of test
        % plotregression(original_test,final_test);
        % figure(3) % regression of fit
        % plotregression(original_fit,final_fit);


        % Error of Model
        switch ModelNumber
            case {1,2}
                figure(4)
                plot(Error);
                legend('Mean Squred Error of Training Phase');
                title('Error','FontName','Arial','FontWeight','Bold','FontSize',15);
                xlabel('Learning Epoch','FontName','Arial','FontSize',12);
                ylabel('MSE','FontName','Arial','FontSize',12);
                elapsedTime = toc;
                MSE_fit = Error(parameters(4));
                MSE_pre = Error_prediction;
                disp(['MSE_fit = ', num2str(MSE_fit)])
                disp(['MSE_predict = ', num2str(MSE_pre)])
                disp(['Time = ', num2str(elapsedTime)])
            case {3,4}
                figure(4)
                plot(per.perf);
                legend('Mean Squred Error of Training Phase');
                title('Convergence','FontName','Arial','FontWeight','Bold','FontSize',15);
                xlabel('Learning Epoch','FontName','Arial','FontSize',12);
                ylabel('MSE','FontName','Arial','FontSize',12);
                elapsedTime = toc;
                switch ModelNumber
                    case 3
                        MSE_fit = per.perf(parameters(3));
                    case 4
                        MSE_fit = per.perf(parameters(4));
                end
                MSE_pre = Error_prediction;
                disp(['MSE_fit = ', num2str(MSE_fit)])
                disp(['MSE_predict = ', num2str(MSE_pre)])
                disp(['Time = ', num2str(elapsedTime)])
            case 5
                figure(4)
                plot(Error);
                legend('Mean Squred Error of Training Phase');
                title('Error','FontName','Arial','FontWeight','Bold','FontSize',15);
                xlabel('Learning Epoch','FontName','Arial','FontSize',12);
                ylabel('MSE','FontName','Arial','FontSize',12);
                elapsedTime = toc;
                MSE_fit = Error(parameters(5));
                MSE_pre = Error_prediction;
                disp(['MSE_fit = ', num2str(MSE_fit)])
                disp(['MSE_predict = ', num2str(MSE_pre)])
                disp(['Time = ', num2str(elapsedTime)])
            case {6,7,8,9,10,11}
                figure(4)
                plot(Error_prediction);
                legend('Mean Squred Error of Training Phase');
                title('Error','FontName','Arial','FontWeight','Bold','FontSize',15);
                xlabel('Learning Epoch','FontName','Arial','FontSize',12);
                ylabel('MSE','FontName','Arial','FontSize',12);
                elapsedTime = toc;
%                 MSE_fit = Error_prediction(parameters(5));
                MSE_pre = Error_prediction;
%                 disp(['MSE_fit = ', num2str(MSE_fit)])
                disp(['MSE_predict = ', num2str(MSE_pre)])
                disp(['Time = ', num2str(elapsedTime)])
        end
    end
    switch ModelNumber
        case 1
            path = ['./','DNM-PSR-',num2str(name(nm)),'.xls'];
        case 2
            path = ['./','Simplified-DNM-',num2str(name(nm)),'.xls'];
        case 3
            path = ['./','Elman-Network-',num2str(name(nm)),'.xls'];
        case 4
            path = ['./','MLP-Network-',num2str(name(nm)),'.xls'];
        case 5
            path = ['./','DNM-BP-',num2str(name(nm)),'.xls'];
        case 6
            path = ['./','DNM-SIS-',num2str(name(nm)),'.xls'];
        case 7
            path = ['./','DNM-SHADE-',num2str(name(nm)),'.xls'];
        case 8
            path = ['./','DNM-DE-',num2str(name(nm)),'.xls'];
        case 9
            path = ['./','DNM-GLPSO-',num2str(name(nm)),'.xls'];
        case 10
            path = ['./','DNM-JADE-',num2str(name(nm)),'.xls'];
        case 11
            path = ['./','DNM-SE-',num2str(name(nm)),'.xls'];
    end
    xlswrite(path,XX);
end