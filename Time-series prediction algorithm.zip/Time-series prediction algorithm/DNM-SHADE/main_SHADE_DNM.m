function [w,q,optimal] = main_SHADE_DNM(Parameter,net,train_data,train_target)
optimal=[];
optimalChart_interval = Parameter.optimalChart_interval;
D = Parameter.D;
l_value=0.5;
M = net.M1;
[~,J] =size(train_data); % J: the dimension of samples
nFES = 0;
iter = 0;
addpath('../');
optimalChart = [];
ProblemSize = D;
n=D;
popsize = Parameter.popsize;
FES = Parameter.FES;
memory_size = 100;memory_pos=1;
% initial population人口初始0化
lu = [-10* ones(1, D); 10* ones(1, D)];
popold = repmat(lu(1, :), popsize, 1) + rand(popsize, D) .* (repmat(lu(2, :) - lu(1, :), popsize, 1));

popuFitness = zeros(popsize,1);
for popindex = 1:popsize
    w = popold(popindex,1:J*M);
    q = popold(popindex,J*M+1:D);
    w = reshape(w,J,M);
    q = reshape(q,J,M);
    net.w = w;
    net.q = q;
    train_fit = my_DNM(train_data,net);
    cost = (train_fit - train_target).^2;
    valParents(popindex,:) = mean(cost);
end
p_min = 2/popsize;
        
        memory_cr = 0.5 * ones(memory_size,1);
        memory_sf = 0.5 * ones(memory_size,1);
        
        Afactor = 1;
        
        archive.NP = Afactor * popsize;     % the maximum size of the archive
        archive.pop = zeros(0, n);          % the solutions stored in te archive
        archive.funvalues = zeros(0, 1);    % the function value of the archived solutions
        
        %% the values and indices of the best solutions
        [valBest, indBest] = sort(valParents, 'ascend');
        
nFES = nFES + popsize;
  %==========================================================================
   while nFES <= FES
           %defination of parameters in memory
            dif_fitness = [];
            success_cr = [];
            success_sf = [];
            
            random_selected_period = randi([1,memory_size],1,1);
            mu_cr = memory_cr(random_selected_period);
            mu_sf = memory_sf(random_selected_period);
            
            %             CR_circle(k_circle)=CRm;
            %             F_circle(k_circle)=Fm;
            
            
            pop = popold; % the old population becomes the current population
            
            
            % Generate CR according to a normal distribution with mean CRm, and std 0.1
            % Generate F according to a cauchy distribution with location parameter Fm, and scale parameter 0.1
            [F, CR] = randFCR(popsize, mu_cr, 0.1, mu_sf, 0.1);
            popAll = [pop; archive.pop];
            [r1, r2] = gnR1R2(popsize, size(popAll, 1));
            
            % Find the p-best solutions
            p_var = (0.2-p_min) * rand + p_min;
            pNP = round(popsize * p_var);
            %             pNP = max(round(p * popsize), 2);            % choose at least two best solutions
            randindex = ceil(rand(1, popsize) * pNP);    % select from [1, 2, 3, ..., pNP]
            randindex = max(1, randindex);               % to avoid the problem that rand = 0 and thus ceil(rand) = 0
            pbest = pop(indBest(randindex), :);          % randomly choose one of the top 100p% solutions
            
            % == == == == == == == Mutation == == == == == == ==
            vi = pop + F(:, ones(1, n)) .* (pbest - pop + pop(r1, :) - popAll(r2, :));
            vi = BoundaryDetection(vi, lu);
            
            % == == == == == == == Crossover == == == == == == ==
            [value,j]=min(valParents);
          
            mask = rand(popsize, n) > CR(:, ones(1, n));                      % mask is used to indicate which elements of ui comes from the parent
            rows = (1 : popsize)'; cols = floor(rand(popsize, 1) * n)+1;      % choose one position where the element of ui doesn't come from the parent
            jrand = sub2ind([popsize n], rows, cols); mask(jrand) = false;
            ui = vi; ui(mask) = pop(mask);

            for popindex = 1:popsize
                w = ui(popindex,1:J*M);
                q = ui(popindex,J*M+1:D);
                w = reshape(w,J,M);
                q = reshape(q,J,M);
                net.w = w;
                net.q = q;
                train_fit = my_DNM(train_data,net);
                cost = (train_fit - train_target).^2;
                valOffspring(popindex,:) = mean(cost);
            end

            nFES = nFES + popsize;
            
            
            % == == == == == == == == == == == == == == == Selection == == == == == == == == == == == == ==
            % I == 1: the parent is better; I == 2: the offspring is better
            
            %Get the successful CR and F
            num_success_param = 0;
            
            for i = 1 : popsize
                if valOffspring(i) < valParents(i)
                    dif_fitness = [dif_fitness abs(valParents(i) - valOffspring(i))];
                    num_success_param = num_success_param + 1;
                    success_cr = [success_cr CR(i)];
                    success_sf = [success_sf F(i)];
                end
            end
            
            [valParents, I] = min([valParents, valOffspring], [], 2);
            
            popold = pop;
            
            archive = updateArchive(archive, popold(I == 1, :), valParents(I == 1));
            
            popold(I == 2, :) = ui(I == 2, :);
            
            if num_success_param > 0
                sum_dif_fitness = 0;
                temp_sum_sf = 0;
                memory_cr(memory_pos) = 0;
                memory_sf(memory_pos) = 0;
                
                for j = 1 : num_success_param
                    sum_dif_fitness = sum_dif_fitness + dif_fitness(j);
                end
                
                for k = 1 : num_success_param
                    weight = dif_fitness(k) / sum_dif_fitness;
                    %weighted arithmetic mean
                    memory_cr(memory_pos) = memory_cr(memory_pos) + weight * success_cr(k);
                    %weighted lehmer mean
                    memory_sf(memory_pos) = memory_sf(memory_pos) + weight * success_sf(k) * success_sf(k);
                    temp_sum_sf = temp_sum_sf + weight * success_sf(k);
                end
                memory_sf(memory_pos) = memory_sf(memory_pos) / temp_sum_sf;
                
                memory_pos = memory_pos + 1;
                if memory_pos > memory_size
                    memory_pos = 1;
                end
            end
            
            [valBest indBest] = sort(valParents, 'ascend');
   end
 gBest=popold(indBest(1),:);
    w = gBest(1:J*M);
    q = gBest(J*M+1:ProblemSize);
    w=reshape(w,J,M);
    q=reshape(q,J,M);
end