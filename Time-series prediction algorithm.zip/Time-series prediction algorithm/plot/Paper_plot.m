data_index = 'DAX30';
load (data_index)

N = length(resid);
rawdata = original(3:N);

STLDNM = xlsread(['Record/New/STL_2_1/',data_index,'_STL_2_1.xls'],'STL_1','B16:B399');%399

MLP = xlsread(['Record/New/MLP_2_1/',data_index,'_MLP_2_1.xls'],'MLP_1','B15:B398');

Elman = xlsread(['Record/New/Elman_2_1/',data_index,'_Elman_2_1.xls'],'Elman_2','D15:D398');

ANFIS = xlsread(['Record/New/ANFIS_3_1/',data_index,'_ANFIS_3_1.xls'],'ANFIS_FCM Clustering','B10:B393');

DNM = xlsread(['Record/New/SD_2_1/',data_index,'_SD_2_1.xls'],'SD_1','B16:B399');

PSRDNM = xlsread(['Record/New/SD_PSR/',data_index,'_SD_PSR.xls'],'SD_1','B16:B383');

PSRSTLDNM = xlsread(['Record/New/STL_PSR/',data_index,'_STL_PSR.xls'],'STL_1','B16:B383');

x = 1:length(rawdata);
x_bounary = round(0.7*(N-2));
size = 0.8;

set(gcf, 'position', [200 500 1200 400]);
plot (x,rawdata,'linewidth',1.5)
hold on
plot(x,STLDNM','--','linewidth',size);
plot(x,MLP','--','linewidth',size);
plot(x,Elman','--','linewidth',size);
plot(x,ANFIS','--','linewidth',size);
plot(x,DNM','--','linewidth',size);
plot(x(18:N-2),PSRDNM','--','linewidth',size);
plot(x(18:N-2),PSRSTLDNM','--','linewidth',size);
hold on
B=get(gca, 'YLim');
plot([x_bounary, x_bounary], [B(1), B(2)], 'k--');
legend('True Value','STLDNM','MLP(10)','Elman(15)','ANFIS(FC)','DNM*','PSR+DNM*','PSR+STLDNM','Location','NorthWest');
xlabel('Data Number','FontName','Arial','FontSize',15);
ylabel('True Value','FontName','Arial','FontSize',15);
text('Position',[x_bounary*1/2,B(2)*2/3],'String','Training','color','k','FontSize',12);
text('Position',[x_bounary + 5,B(2)*5/6],'String','Testing','color','k','FontSize',12);
hold off

STLDNM = STLDNM'-rawdata;
MLP = MLP'-rawdata;
Elman = Elman'-rawdata;
ANFIS = ANFIS'-rawdata;
DNM = DNM'-rawdata;
PSRDNM = PSRDNM'-(rawdata(18:N-2));
PSRSTLDNM = PSRSTLDNM'-(rawdata(18:N-2));

figure(2)
set(gcf, 'position', [400 200 1200 400]);
plot (x,rawdata-rawdata,'linewidth',1.5)
hold on
plot(x,STLDNM','--','linewidth',size);
plot(x,MLP','--','linewidth',size);
plot(x,Elman','--','linewidth',size);
plot(x,ANFIS','--','linewidth',size);
plot(x,DNM','--','linewidth',size);
plot(x(18:N-2),PSRDNM','--','linewidth',size);
plot(x(18:N-2),PSRSTLDNM','--','linewidth',size);
hold on
B=get(gca, 'YLim');
plot([x_bounary, x_bounary], [B(1), B(2)], 'k--');
legend('Baseline','STLDNM','MLP(10)','Elman(15)','ANFIS(FC)','DNM*','PSR+DNM*','PSR+STLDNM','Location','SouthWest');
xlabel('Data Number','FontName','Arial','FontSize',15);
ylabel('Deviation Value','FontName','Arial','FontSize',15);
text('Position',[x_bounary*2/3,B(2)*-2/3],'String','Training','color','k','FontSize',12);
text('Position',[x_bounary + 5,B(2)*-2/3],'String','Testing','color','k','FontSize',12);
hold off