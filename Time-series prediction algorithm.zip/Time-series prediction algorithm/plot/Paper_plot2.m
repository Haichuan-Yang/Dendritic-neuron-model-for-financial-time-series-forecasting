data_index = 'DJIA-90';
load (data_index)

N = length(resid);
rawdata = original(3:N);
bounary = round(0.7*(N-2));

filename = 'DE.xlsx';
sheet = 1;
xlRange = 'A1:ARW1';

SSDNM = xlsread(filename,sheet,xlRange);
% STLDNM = xlsread(['Record/New/STL_2_1/',data_index,'_STL_2_1.xls'],'STL_1','B16:B434');
% STLDNM = xlsread(['Record/New/Elman_2_1/',data_index,'_Elman_2_1.xls'],'Elman_2','B15:B433');


train_o = rawdata(1:bounary);
train_p = SSDNM(1:bounary);
test_o = rawdata(bounary+1:end);
test_p = SSDNM(bounary+1:end);

figure(1)
plotregression(train_o,train_p);
figure(2)
plotregression(test_o,test_p);

% %PSR
% N = length(resid);
% rawdata = original(8:N);
% bounary = round(0.7*414);
% 
% STLDNM = xlsread(['Record/New/STL_PSR/',data_index,'_STL_PSR.xls'],'STL_1','B16:B429');
% 
% train_o = rawdata(1:bounary);
% train_p = STLDNM(1:bounary);
% test_o = rawdata(bounary+1:end);
% test_p = STLDNM(bounary+1:end);
% 
% figure(1)
% plotregression(train_o,train_p);
% figure(2)
% plotregression(test_o,test_p);

