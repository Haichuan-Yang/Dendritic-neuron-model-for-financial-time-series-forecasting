data_index = 'Chengdu';
load (data_index)

N = length(resid);
rawdata = original(3:N);

filename = 'huigui.xlsx';
sheet = 1;
xlRange = 'A8:AXG8';
SSDNM = xlsread(filename,sheet,xlRange);

filename = 'huigui.xlsx';
sheet = 1;
xlRange = 'A1:AXG1';
Elman = xlsread(filename,sheet,xlRange);

filename = 'huigui.xlsx';
sheet = 1;
xlRange = 'A2:AXG2';
SVM_R_B_F = xlsread(filename,sheet,xlRange);

% filename = 'huigui.xlsx';
% sheet = 1;
% xlRange = 'A3:AXG3';
% SVM_S_F = xlsread(filename,sheet,xlRange);

filename = 'huigui.xlsx';
sheet = 1;
xlRange = 'A4:AXG4';
SVM_L_F = xlsread(filename,sheet,xlRange);

filename = 'ssdnm.xlsx';
sheet = 1;
xlRange = 'A5:AXG5';
ANFIS = xlsread(filename,sheet,xlRange);

filename = 'huigui.xlsx';
sheet = 1;
xlRange = 'A6:AXG6';
MLP = xlsread(filename,sheet,xlRange);

filename = 'huigui.xlsx';
sheet = 1;
xlRange = 'A7:AXG7';
LSTM = xlsread(filename,sheet,xlRange);
% STLDNM = xlsread(['Record/New/STL_2_1/',data_index,'_STL_2_1.xls'],'STL_1','B16:B399');%399

% MLP = xlsread(['Record/New/MLP_2_1/',data_index,'_MLP_2_1.xls'],'MLP_1','B15:B398');
% 
% Elman = xlsread(['Record/New/Elman_2_1/',data_index,'_Elman_2_1.xls'],'Elman_2','D15:D398');
% 
% ANFIS = xlsread(['Record/New/ANFIS_3_1/',data_index,'_ANFIS_3_1.xls'],'ANFIS_FCM Clustering','B10:B393');
% 
% DNM = xlsread(['Record/New/SD_2_1/',data_index,'_SD_2_1.xls'],'SD_1','B16:B399');
% 
% PSRDNM = xlsread(['Record/New/SD_PSR/',data_index,'_SD_PSR.xls'],'SD_1','B16:B383');
% 
% PSRSTLDNM = xlsread(['Record/New/STL_PSR/',data_index,'_STL_PSR.xls'],'STL_1','B16:B383');

x = 1:length(rawdata);
x_bounary = round(0.7*(N-2));
size = 0.8;

set(gcf, 'position', [200 500 1200 400]);
plot (x,rawdata,'linewidth',1.5)
hold on
plot(x,SSDNM,'--','linewidth',size);
plot(x,Elman,'--','linewidth',size);
plot(x,SVM_R_B_F,'--','linewidth',size);
% plot(x,SVM_S_F,'--','linewidth',size);
plot(x,SVM_L_F,'--','linewidth',size);
plot(x,ANFIS,'--','linewidth',size);
plot(x,MLP,'--','linewidth',size);
plot(x,LSTM,'--','linewidth',size);
hold on
B=get(gca, 'YLim');
plot([x_bounary, x_bounary], [B(1), B(2)], 'k--');
legend('True Value','SSDNM','Elman','SVM_R_B_F','SVM_L_F','ANFIS','MLP','LSTM','Location','NorthWest');
xlabel('Data Number','FontName','Arial','FontSize',15);
ylabel('True Value','FontName','Arial','FontSize',15);
text('Position',[x_bounary*1/2,B(2)*-2/3],'String','Training','color','k','FontSize',12);
text('Position',[x_bounary + 5,B(2)*-5/6],'String','Testing','color','k','FontSize',12);
hold off

STLDNM = SSDNM-rawdata;
Elman = Elman-rawdata;
SVM_R_B_F = SVM_R_B_F-rawdata;
% SVM_S_F = SVM_S_F-rawdata;
SVM_L_F = SVM_L_F-rawdata;
ANFIS = ANFIS-rawdata;
MLP = MLP-rawdata;
LSTM = LSTM-rawdata;

figure(2)
set(gcf, 'position', [400 200 1200 400]);
plot (x,rawdata-rawdata,'linewidth',1.5)
hold on
plot(x,SSDNM,'--','linewidth',size);
plot(x,Elman,'--','linewidth',size);
plot(x,SVM_R_B_F,'--','linewidth',size);
% plot(x,SVM_S_F,'--','linewidth',size);
plot(x,SVM_L_F,'--','linewidth',size);
plot(x,ANFIS,'--','linewidth',size);
plot(x,MLP,'--','linewidth',size);
plot(x,LSTM,'--','linewidth',size);
hold on
B=get(gca, 'YLim');
plot([x_bounary, x_bounary], [B(1), B(2)], 'k--');
legend('Baseline','SSDNM','Elman','SVM_R_B_F','SVM_L_F','ANFIS','MLP','LSTM','Location','SouthWest');
xlabel('Data Number','FontName','Arial','FontSize',15);
ylabel('Deviation Value','FontName','Arial','FontSize',15);
text('Position',[x_bounary*2/3,B(2)*2/3],'String','Training','color','k','FontSize',12);
text('Position',[x_bounary + 5,B(2)*2/3],'String','Testing','color','k','FontSize',12);
hold off