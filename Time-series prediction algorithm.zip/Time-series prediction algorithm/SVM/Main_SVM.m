%% Data load & PSR

tic

 load Chengdu
 m = 2;
 tau = 1;

N = length(original)-1; % data length to reconstruct, -1 for the last element not in the PSR matrix.
M = N-(m-1)*tau; % PSR matrix data length
Boundary = round(0.7*M); % trainning data length
n = M-Boundary; % testing data length

PSR_matrix = zeros(m,M); % construct PSR matrix
for i=1:m
    PSR_matrix(i,:) = original((1+(i-1)*tau):(M+(i-1)*tau));
end
PSR_target = original(N-M+2:end);
trainx = PSR_matrix(1:m,1:Boundary);
trainy = PSR_target(1:Boundary);
testx = PSR_matrix(1:m,Boundary+1:M);
testy = PSR_target(Boundary+1:M);


%% Traning

mse = 10^7;
for log2c = -10:0.5:3
    for log2g = -10:0.5:3
        cmd = ['-v 3 -c ', num2str(2^log2c), ' -g ', num2str(2^log2g) , ' -s 3 -p 0.4 '];
        cv = fitrsvm(trainx',trainy');
        if (cv < mse)
            mse = cv;
            bestc = 2^log2c;
            bestg = 2^log2g;
        end
    end
end

cmd = ['-c ', num2str(2^bestc), ' -g ', num2str(2^bestg) , ' -s 3 -p 0.4 -n 0.1'];
model =svmtrain(trainy', trainx', [cmd,' ',ttt]);

%% Predicting

[final] = svmpredict(testy', testx', model);

%% Error Calculation

final_test = final';
original_test = testy;
n = length(testy);

MSE = 1/n*sum((final_test - original_test).^2);
MAPE = 1/n*sum(abs((original_test - final_test)/original_test));
MAE = 1/n*sum(abs((original_test - final_test)));
RMSE = MSE^0.5;
R_pre = sum((original_test-mean(original_test)).*(final_test-mean(final_test)))/((sum((original_test-mean(original_test)).^2*sum((final_test-mean(final_test)).^2)))^0.5);
elapsedTime =toc;

disp(['MSE = ', num2str(MSE)])
disp(['MAPE = ', num2str(MAPE)])
disp(['MAE = ', num2str(MAE)])
disp(['RMSE = ', num2str(RMSE)])
disp(['R_predict = ', num2str(R_pre)])
disp(['Time = ', num2str(elapsedTime)])
