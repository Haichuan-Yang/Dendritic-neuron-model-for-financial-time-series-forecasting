% ============================= %
% Using genfis fuctions suggested by Matlab Documents
% Developed by Haichuan Yang (0000-0001-7100-7945) 2022.12
% Run Main_LSTM for all data
% ============================= %

tic
clear all;
name = ["SP500-90"];
X=[];
for nm=1:length(name)
    for r = 1 : 30

        load (name(nm))
        tic
        data = original;
        numTimeStepsTrain = floor(0.7*numel(data));
        dataTrain = data(1:numTimeStepsTrain+1);
        dataTest = data(numTimeStepsTrain+1:end);

        %% Nomalize

        mu = mean(dataTrain);
        sig = std(dataTrain);
        dataTrainStandardized = (dataTrain - mu) / sig;

        %% Prepare Response

        XTrain = dataTrainStandardized(1:end-1);
        YTrain = dataTrainStandardized(2:end);

        %% Bulid Network

        numFeatures = 1;
        numResponses = 1;
        numHiddenUnits = 15;

        layers = [ ...
            sequenceInputLayer(numFeatures)
            lstmLayer(numHiddenUnits)
            fullyConnectedLayer(numResponses)
            regressionLayer];

        options = trainingOptions('adam', ...
            'MaxEpochs',1000, ...
            'GradientThreshold',1, ...
            'InitialLearnRate',0.1, ...
            'LearnRateSchedule','piecewise', ...
            'LearnRateDropPeriod',150, ...
            'LearnRateDropFactor',0.1, ...
            'Verbose',0, ...
            'Plots','training-progress');

        %% Training

        net = trainNetwork(XTrain,YTrain,layers,options);

        %% Predicting

        dataTestStandardized = (dataTest - mu) / sig;
        XTest = dataTestStandardized(1:end-1);
        net = predictAndUpdateState(net,XTrain);

        YPred = [];
        numTimeStepsTest = numel(XTest);
        for i = 1:numTimeStepsTest
            [net,YPred(:,i)] = predictAndUpdateState(net,XTest(:,i),'ExecutionEnvironment','cpu');
        end

        YPred = sig*YPred + mu; % de-normalize
        YTest = dataTest(2:end);
        rmse = sqrt(mean((YPred-YTest).^2));

        %% Error Calculation

        final_test = YPred;
        original_test = YTest;
        n = length(YTest);

        MSE = 1/n*sum((final_test - original_test).^2);
        MAPE = 1/n*sum(abs((original_test - final_test)/original_test));
        MAE = 1/n*sum(abs((original_test - final_test)));
        RMSE = MSE^0.5;
        R_pre = sum((original_test-mean(original_test)).*(final_test-mean(final_test)))/((sum((original_test-mean(original_test)).^2*sum((final_test-mean(final_test)).^2)))^0.5);
        elapsedTime =toc;

        disp(['MSE = ', num2str(MSE)]);
        disp(['MAPE = ', num2str(MAPE)]);
        disp(['MAE = ', num2str(MAE)]);
        disp(['RMSE = ', num2str(RMSE)]);
        disp(['R_predict = ', num2str(R_pre)]);
        disp(['Time = ', num2str(elapsedTime)]);
        X(r,:)=[MSE,MAPE,MAE];
    end
    path = ['./','LSTM-',num2str(name(nm)),'.xls'];
    sheetName = ['DNM_' '_F'];
    xlswrite(path,X);
end