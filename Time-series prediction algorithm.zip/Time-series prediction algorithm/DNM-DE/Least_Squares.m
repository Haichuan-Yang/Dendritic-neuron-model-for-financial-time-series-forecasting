% Least Squares Method for trend prediction

function [lsp] = Least_Squares(trend,N,M)
    xdata = [1:N];
    ydata = trend(1:N);
    [p,S] = polyfit(xdata,ydata,3);
    [temp,delta] = polyval(p,xdata,S);
    lsp = temp(N-M+1:N);
end