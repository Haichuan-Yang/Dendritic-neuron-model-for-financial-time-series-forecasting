function [w,q,optimal,out] = main_DE_DNM(Parameter,net,train_data,train_target)
optimal=[];
optimalChart_interval = Parameter.optimalChart_interval;
D = Parameter.D;
l_value=0.5;
M = net.M1;
[~,J] =size(train_data); % J: the dimension of samples
nFES = 0;
iter = 0;
addpath('../');
optimalChart = [];
ProblemSize = D;

PopSize = Parameter.popsize;
FES = Parameter.FES;

% initial population人口初始0化
lu = [-10* ones(1, D); 10* ones(1, D)];
popold = repmat(lu(1, :), PopSize, 1) + rand(PopSize, D) .* (repmat(lu(2, :) - lu(1, :), PopSize, 1));

Fitness = zeros(PopSize,1);
for popindex = 1:PopSize
    w = popold(popindex,1:J*M);
    q = popold(popindex,J*M+1:D);
    w = reshape(w,J,M);
    q = reshape(q,J,M);
    net.w = w;
    net.q = q;
    train_fit = my_DNM(train_data,net);
    cost = (train_fit - train_target).^2;
    Fitness(popindex) = mean(cost);
end

fit = Fitness;
F = 0.5;
CR = 0.9;
popu= popold;

gBestFit = 1e+30;
BciSolution = zeros(1, ProblemSize);
    for i = 1 : PopSize
        nFES = nFES + 1;
        if fit(i) < gBestFit
            gBestFit = fit(i);
            BciSolution = popold(i, :);
        end
        if mod(nFES, optimalChart_interval) == 0
            optimalChart = [optimalChart;gBestFit];
        else
            if nFES == FES
                optimalChart = [optimalChart;gBestFit];
            end
        end
        %             optimalChart = [optimalChart;gBestFit];
        if nFES >= FES; break; end
    end
  %==========================================================================
   while nFES <= FES
            
            % Get indices for mutation
            [r1, r2, r3] = getindex(PopSize);
            
            % Implement DE/rand/1 mutation
            V = popu(r1, :) + F * (popu(r2, :) - popu(r3, :));
            
            % Check whether the mutant vector violates the boundaries or not
%             V = repair(V, lu(1,1),lu(2,1));
            [V] = BoundaryDetection(V,lu);

            % Implement binomial crossover
            for i = 1:PopSize
                
                j_rand = floor(rand * D) + 1;
                t = rand(1, D) < CR;
                t(1, j_rand) = 1;
                t_ = 1 - t;
                U(i, :) = t .* V(i, :) + t_ .* popu(i, :);
            end

            for popindex = 1:PopSize
                w = U(popindex,1:J*M);
                q = U(popindex,J*M+1:D);
                w = reshape(w,J,M);
                q = reshape(q,J,M);
                net.w = w;
                net.q = q;
                train_fit = my_DNM(train_data,net);
                cost = (train_fit - train_target).^2;
                fit_U(popindex,:) = mean(cost);
            end

            for i = 1 : PopSize
                nFES = nFES + 1;
                if fit_U(i) < gBestFit
                    gBestFit = fit_U(i);
                    best_population=U(i,:);
                end
                if mod(nFES, optimalChart_interval) == 0
                    optimalChart = [optimalChart;gBestFit];
                else
                    if nFES == FES
                        optimalChart = [optimalChart;gBestFit];
                    end
                end
                if fit_U(i, :) <= fit(i, :)
                    popu(i, :) = U(i, :);
                    fit(i, :) = fit_U(i, :);
                end
                if nFES > FES; break; end
            end
   end

  
    
    w = best_population(1:J*M);
    q = best_population(J*M+1:ProblemSize);
    w=reshape(w,J,M);
    q=reshape(q,J,M);
end