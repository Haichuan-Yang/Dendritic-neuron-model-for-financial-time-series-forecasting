function [w,q,optimal,out] = main_SE_DNM(Parameter,net,train_data,train_target)
type=4;
optimal=[];
optimalChart_interval = Parameter.optimalChart_interval;
D = Parameter.D;
l_value=0.5;
M = net.M1;
[~,J] =size(train_data); % J: the dimension of samples
nFES = 0;
iter = 0;
addpath('../');
optimalChart = [];
ProblemSize = D;

popuSize = Parameter.popsize;
FES = Parameter.FES;

% initial population人口初始0化

lu = [-10* ones(1, D); 10* ones(1, D)];
popu = repmat(lu(1, :), popuSize, 1) + rand(popuSize, D) .* (repmat(lu(2, :) - lu(1, :), popuSize, 1));

popuFitness = zeros(popuSize,1);
for popindex = 1:popuSize
    w = popu(popindex,1:J*M);
    q = popu(popindex,J*M+1:D);
    w = reshape(w,J,M);
    q = reshape(q,J,M);
    net.w = w;
    net.q = q;
    train_fit = my_DNM(train_data,net);
    cost = (train_fit - train_target).^2;
    popuFitness(popindex) = mean(cost);
end

popuOld = popu;
fitOld = popuFitness;
gBestFit = 1e+30;
BciSolution = zeros(1, ProblemSize);
    for i = 1 : popuSize
        nFES = nFES + 1;
        if popuFitness(i) < gBestFit
            gBestFit = popuFitness(i);
            BciSolution = popu(i, :);
        end
        if mod(nFES, optimalChart_interval) == 0
            optimalChart = [optimalChart;gBestFit];
        else
            if nFES == FES
                optimalChart = [optimalChart;gBestFit];
            end
        end
        %             optimalChart = [optimalChart;gBestFit];
        if nFES >= FES; break; end
    end
  %==========================================================================
   while nFES <= FES
            
           [valBest, indBest] = sort(popuFitness, 'ascend');
            optimal = popu(indBest(1),:);
            [~,I] = sort(popuFitness);
            SF = zeros(1,popuSize);
            DSF = zeros(1,popuSize);
            for i = 1:popuSize
                SF(I(i)) = i / popuSize + 0.1 * randn();
                if SF(I(i)) > 1
                    SF(I(i)) = 1;
                elseif SF(I(i)) < 0
                    SF(I(i)) = i / popuSize;
                end
                if D >= 10
                    DSF(i) = 5 + randperm(5,1);
                else
                    DSF(i) = 3;
                    if D==1
                      DSF(i) = 1;
                    end
                end
            end
            
            for i = 1:popuSize
                randPopuList = randperm(popuSize);
                randPopuList = setdiff(randPopuList,1,'stable');
                indiR1 = popu(randPopuList(1),:);
                indiR2 = popu(randPopuList(2),:);
                indiR3 = popu(randPopuList(3),:);
                indiR4 = popu(randPopuList(4),:);
                indiR5 = popu(randPopuList(5),:);
                
                randDimList = randperm(D);
                randDSFList = randperm(DSF(i));
                
                seleDim = sort(randDimList(1:randDSFList(1)));
                
                seleDimLen = length(seleDim);
                if seleDimLen == 1
                    s1= SF(i)*HyperSphereTransform_1D(indiR1,indiR2,seleDim);
                    s2= SF(i)*HyperSphereTransform_1D(indiR3,indiR4,seleDim);
                    s3= SF(i)*HyperSphereTransform_1D(popu(i,:),optimal,seleDim);
                elseif seleDimLen == 2
                    s1= SF(i)*HyperSphereTransform_2D(indiR1,indiR2,seleDim);
                    s2= SF(i)*HyperSphereTransform_2D(indiR3,indiR4,seleDim);
                    s3= SF(i)*HyperSphereTransform_2D(popu(i,:),optimal,seleDim);
                else
                    s1= SF(i)*HyperSphereTransform(indiR1,indiR2,seleDim);
                    s2= SF(i)*HyperSphereTransform(indiR3,indiR4,seleDim);
                    s3= SF(i)*HyperSphereTransform(popu(i,:),optimal,seleDim);
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
                b = 1-nFES/FES;                                        % a decreases linearly fron 1 to 0
                                                                           % Find the p-best solutions
                pNP = max(round(b * popuSize), 1);                         % choose  best solutions
                randindex = ceil(rand * pNP);                              % select from [1, 2, 3, ..., pNP]
                randindex = max(1, randindex);                             % to avoid the problem that rand = 0 and thus ceil(rand) = 0
                pbest = popu(indBest(randindex), :);                       % randomly choose one of the top 100p% solutions
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                switch type
                    case 1%SE/current-to-best/1
                        popu(i,seleDim) = popu(i,seleDim) + s3 + s2;
                    case 2%SE/best/1
                        popu(i,seleDim) = optimal(seleDim) + s1;
                    case 3%SE/best/2
                        popu(i,seleDim) = optimal(seleDim) + s1 + s2;
                    case 4%SE/rand/1
                        popu(i,seleDim) = indiR5(seleDim) + s1;
                    case 5%SE/rand/2
                        popu(i,seleDim) = indiR5(seleDim) + s1 + s2;
                    case 6 %SE/current/1
                        popu(i,seleDim) = popu(i,seleDim) + s1;
                    case 7 %SE/current/2
                        popu(i,seleDim) = popu(i,seleDim) + s1  + s2 ;
                    case 8
                        popu(i,seleDim) = pbest(seleDim) + s1;
                end
            end
            [popu]= BoundaryDetection(popu,lu);

            for popindex = 1:popuSize
                w = popu(popindex,1:J*M);
                q = popu(popindex,J*M+1:D);
                w = reshape(w,J,M);
                q = reshape(q,J,M);
                net.w = w;
                net.q = q;
                train_fit = my_DNM(train_data,net);
                cost = (train_fit - train_target).^2;
                popuFitness(popindex,:) = mean(cost);
            end

            for i = 1 : popuSize
                nFES = nFES + 1;
                if popuFitness(i) < gBestFit
                    gBestFit = popuFitness(i);
                    best_population=popu(i,:);
                end
                if mod(nFES, optimalChart_interval) == 0
                    optimalChart = [optimalChart;gBestFit];
                else
                    if nFES == FES
                        optimalChart = [optimalChart;gBestFit];
                    end
                end
                if popuFitness(i) < fitOld(i)
                    fitOld(i) = popuFitness(i);
                    popuOld(i,:) = popu(i,:);
                end
                if nFES > FES; break; end
            end
            popu = popuOld;
   end

  
    
    w = best_population(1:J*M);
    q = best_population(J*M+1:ProblemSize);
    w=reshape(w,J,M);
    q=reshape(q,J,M);
end

function ss = HyperSphereTransform(c,d,pp)
D=length(pp);
A=c(pp)-d(pp);
R=norm(A,2);

O(D-1)=  2*pi*rand ;


for i=1:D-2
    O(i)=  rand*pi  ;
end

% 转换直角坐眮E
C(1)=R*prod(sin(O));
for i=2:D-1
    C(i)= R*cos(O(i-1)) *prod(sin(O(i:D-1)));
end
C(D)=R*cos(O(D-1));
ss=C;
end

function ss = HyperSphereTransform_1D(c,d,pp)
R=  abs(c(pp)-d(pp));
C = R*cos(2*pi*rand);
ss=C;
end

function ss = HyperSphereTransform_2D(c,d,pp)
A=c(pp)-d(pp);
R=norm(A,2);
o1=2*pi*rand;
C=zeros(1,2);
C(1) =R*sin(o1);
C(2) =R*cos(o1);
ss=C;
end
