clc,clear all;
benchmark = 'CEC2017';
dim = 50;
problemNum =15;
% name
algorithmA = 'Elman';
algorithmB = 'ANFIS';
statisticPath = ['./', benchmark, '_', num2str(dim) ,'_',algorithmA,'_vs',algorithmB,'_Statistic_RankSum.xlsx'];
tableOfRankSumTest = initTableforBoxPlot(problemNum,algorithmA,algorithmB);
% data path
pathA = 'Elman.xlsx';
pathB = 'ANFIS.xlsx';
dataA = xlsread(pathA,['D2:','AG',num2str(problemNum + 1)]);
dataB = xlsread(pathB,['D2:','AG',num2str(problemNum + 1)]);
w = 0;
t = 0;
l = 0;
for i = 1:problemNum
    pAB = ranksum(dataA(i,:),dataB(i,:),'tail','left');
    pBA = ranksum(dataB(i,:),dataA(i,:),'tail','left');
    if pAB <= 0.05 && pBA >= 0.05
        tableOfRankSumTest{i+2,2} = 1;
        w = w + 1;
    elseif pAB >=0.05 && pBA <= 0.05
        tableOfRankSumTest{i+2,4} = 1;
        l = l + 1;
    else
        tableOfRankSumTest{i+2,3} = 1;
        t = t + 1;
    end
end
tableOfRankSumTest{3+problemNum,2} = w;
tableOfRankSumTest{3+problemNum,3} = t;
tableOfRankSumTest{3+problemNum,4} = l;
xlswrite(statisticPath,tableOfRankSumTest);

function tableSR = initTableforBoxPlot(problemNum,algorithmA,algorithmB)
row = problemNum + 3;
col = 4;
tableSR = cell(row, col);
tableSR{1,2} = algorithmA;
tableSR{1,3} = 'VS';
tableSR{1,4} = algorithmB;
tableSR{2,2} = 'Win';
tableSR{2,3} = 'Tie';
tableSR{2,4} = 'Lose';
for i = 1:problemNum
    tableSR{i+2,1} = ['F' num2str(i)];
end
tableSR{3+problemNum,1} = 'W/T/L';
end