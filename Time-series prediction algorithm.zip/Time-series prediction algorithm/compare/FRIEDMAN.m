clear all
format short
index = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG'};
fun=2;

pathA = 'ANFIS.xlsx';
pathB = 'Elman.xlsx';
pathC = 'MLP.xlsx';
pathD = 'DNM-BP.xlsx';
pathE = 'DNM-SIM.xlsx';
pathF = 'DNM-SHADE-50000.xlsx';
% pathG = 'DNM-JADE-50000.xlsx';
% pathH = 'DNM-DE-50000.xlsx';
% pathI = 'DNM-SE-50000.xlsx';
% pathJ = 'DNM-SIS-50000.xlsx';
% pathK = 'DNM-GLPSO-50000.xlsx';
pathL = 'LSTM.xlsx';
A = xlsread(pathA,[index{fun},'2:',index{fun},'16']);
B = xlsread(pathB,[index{fun},'2:',index{fun},'16']);
C = xlsread(pathC,[index{fun},'2:',index{fun},'16']);
D = xlsread(pathD,[index{fun},'2:',index{fun},'16']);
E = xlsread(pathE,[index{fun},'2:',index{fun},'16']);
F = xlsread(pathF,[index{fun},'2:',index{fun},'16']);
% G = xlsread(pathG,[index{fun},'2:',index{fun},'16']);
% H = xlsread(pathH,[index{fun},'2:',index{fun},'16']);
% I = xlsread(pathI,[index{fun},'2:',index{fun},'16']);
% J = xlsread(pathJ,[index{fun},'2:',index{fun},'16']);
% K = xlsread(pathK,[index{fun},'2:',index{fun},'16']);
L = xlsread(pathL,[index{fun},'2:',index{fun},'16']);

data=[A,B,C,D,E,F,L];
[~,~,r]=friedman(data)