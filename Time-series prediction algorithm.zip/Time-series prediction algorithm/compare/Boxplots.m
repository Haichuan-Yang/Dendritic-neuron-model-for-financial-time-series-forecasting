clc;clear all;
problem =1;
Data0=xlsread('ANFIS.xlsx',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
Data1=xlsread('DNM-DE-50000.xlsx',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
Data2=xlsread('HGSA_CEC2017_D30_Mean&Std_and_Box-Plot.xls',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
Data3=xlsread('MDBSO_CEC2017_D30_Mean&Std_and_Box-Plot.xls',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
% Data4=xlsread('GLPSO_CEC2017_D30_Mean&Std_and_Box-Plot.xls',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
%Data5=xlsread('SE04_chaos_5_CEC2017_D30_Mean&Std_and_Box-Plot.xlsx',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
%Data6=xlsread('SE04_chaos_6_CEC2017_D30_Mean&Std_and_Box-Plot.xlsx',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
%Data7=xlsread('SE04_chaos_7_CEC2017_D30_Mean&Std_and_Box-Plot.xlsx',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
%Data8=xlsread('SE04_chaos_8_CEC2017_D30_Mean&Std_and_Box-Plot.xlsx',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
%Data9=xlsread('SE04_chaos_9_CEC2017_D30_Mean&Std_and_Box-Plot.xlsx',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
%Data10=xlsread('SE04_chaos_10_CEC2017_D30_Mean&Std_and_Box-Plot.xlsx',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
%Data11=xlsread('SE04_chaos_11_CEC2017_D30_Mean&Std_and_Box-Plot.xlsx',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
%Data12=xlsread('SE04_chaos_12_CEC2017_D30_Mean&Std_and_Box-Plot.xlsx',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
%Data13=xlsread('SE04_chaos_13_CEC2017_D30_Mean&Std_and_Box-Plot.xlsx',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
%Data14=xlsread('SE04_chaos_14_CEC2017_D30_Mean&Std_and_Box-Plot.xlsx',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
%Data15=xlsread('SE04_chaos_15_CEC2017_D30_Mean&Std_and_Box-Plot.xlsx',[['D', num2str(problem+1)],':',['AG', num2str(problem+1)]]);
% Data4=xlsread('D:\ComputionalIntelligence\SCA\SCA 17.xlsx',['A', num2str(problem+1)],':',['AG', num2str(problem+1)]);

% Data5=xlsread('C:\Users\GSHXD\Documents\DATA\DATA\10000D\CEC17\GSA 17.xlsx','sheet26','A3000:AD3000');
% Data6=xlsread('C:\Users\GSHXD\Documents\DATA\DATA\10000D\CEC17\GWO 17.xlsx','sheet26','A3000:AD3000');
% Data7=xlsread('C:\Users\GSHXD\Documents\DATA\DATA\10000D\ABC variants DATA\ABC 17','sheet26','A3000:AD3000');
% Data8=xlsread('C:\Users\GSHXD\Documents\DATA\DATA\10000D\CEC17\WOA 17.xlsx','sheet26','A3000:AD3000');

% Data1=Data1+200*ones(1,30);  % %  ���ָ�ֵ���ô˶Σ�200�Ǳ��⸺ֵ�����򵣬30��ά??
% Data2=Data2+200*ones(1,30);
% Data3=Data3+200*ones(1,30);
% Data4=Data4+200*ones(1,30);
% Data5=Data5+200*ones(1,30);
% Data6=Data6+200*ones(1,30);
% Data7=Data7+200*ones(1,30);
% Data8=Data8+200*ones(1,30);

Box=[Data0' Data1'];
% Box=[Data0' Data1'];
boxplot(Box,{'CDE','DE'})
% boxplot(Box,{'CWFS','WFS'})
title(['Solution Distribution:F',num2str(problem)], 'FontName','Times New Roman','FontSize',18);
ylabel('Error','FontName','Times New Roman','FontSize',18);
xlabel('Algorithm','FontName','Times New Roman','FontSize',18);