% ============================= %
% Modified Version of Yarpiz's ANFIS
% Using genfis fuctions suggested by Matlab Documents
% Developed by Haichuan Yang (0000-0001-7100-7945) 2022.12
% Run Main_ANFIS for all data
% ============================= %

clear all;
name = ["DJIA-360","NASDAQCOM-360", "NDX100-360", "NIKKEI225-360", "SP500-360"];
tic
for nm=1:length(name)
    %% Create Time-Series Data
    load (name(nm))
    m = 2; % embedding dimension (using m-1 to predict)
    tau = 1; % time delay

    N = length(original); % original data length
    M = N-(m-1)*tau; % experimental data length

    original_n = zeros(m,M); % construct PSR matrix
    for i=1:m
        original_n(i,:) = original((1+(i-1)*tau):(M+(i-1)*tau));
    end
    Inputs = original_n(1:m-1,1:M)';
    Targets = original_n(m,1:M)';

    nData = size(Inputs,1);

    %% Shuffling Data

    PERM = 1:nData; % Permutation to Shuffle Data

    pTrain=0.7;
    nTrainData=round(pTrain*nData);
    TrainInd=PERM(1:nTrainData);
    TrainInputs=Inputs(TrainInd,:);
    TrainTargets=Targets(TrainInd,:);

    pTest=1-pTrain;
    nTestData=nData-nTrainData;
    TestInd=PERM(nTrainData+1:end);
    TestInputs=Inputs(TestInd,:);
    TestTargets=Targets(TestInd,:);
    XX=[];
    for time=1:30

        %% Setting the Parameters of FIS Generation Methods
        opt= genfisOptions('SubtractiveClustering');
        fis = genfis(TrainInputs,TrainTargets,opt);

        %% Training ANFIS Structure

        PARAMS={'100', '0', '0.01', '0.9', '1.1'};
        MaxEpoch=str2num(PARAMS{1});                %#ok
        ErrorGoal=str2num(PARAMS{2});               %#ok
        InitialStepSize=str2num(PARAMS{3});         %#ok
        StepSizeDecreaseRate=str2num(PARAMS{4});    %#ok
        StepSizeIncreaseRate=str2num(PARAMS{5});    %#ok
        TrainOptions=[MaxEpoch ...
            ErrorGoal ...
            InitialStepSize ...
            StepSizeDecreaseRate ...
            StepSizeIncreaseRate];

        DisplayInfo=true;
        DisplayError=true;
        DisplayStepSize=true;
        DisplayFinalResult=true;
        DisplayOptions=[DisplayInfo ...
            DisplayError ...
            DisplayStepSize ...
            DisplayFinalResult];

        OptimizationMethod=0;
        % 0: Backpropagation
        % 1: Hybrid

        fis=anfis([TrainInputs TrainTargets],fis,TrainOptions,DisplayOptions,[],OptimizationMethod);

        %% Apply ANFIS to Data

        Outputs=evalfis(fis,Inputs);
        TrainOutputs=Outputs(TrainInd,:);
        TestOutputs=Outputs(TestInd,:);
        final = [TrainOutputs',TestOutputs'];

        %% Error Calculation

        final_fit = TrainOutputs';
        final_test = TestOutputs';
        original_fit = TrainTargets';
        original_test = TestTargets';
        n = length(TestTargets);

        MSE = 1/n*sum((final_test - original_test).^2);
        MAPE = 1/n*sum(abs((original_test - final_test)/original_test));
        MAE = 1/n*sum(abs((original_test - final_test)));
        RMSE = MSE^0.5;
        R_fit = sum((original_fit-mean(original_fit)).*(final_fit-mean(final_fit)))/((sum((original_fit-mean(original_fit)).^2*sum((final_fit-mean(final_fit)).^2)))^0.5);
        R_pre = sum((original_test-mean(original_test)).*(final_test-mean(final_test)))/((sum((original_test-mean(original_test)).^2*sum((final_test-mean(final_test)).^2)))^0.5);
        elapsedTime =toc;

        disp(['MSE = ', num2str(MSE)])
        disp(['MAPE = ', num2str(MAPE)])
        disp(['MAE = ', num2str(MAE)])
        disp(['RMSE = ', num2str(RMSE)])
        disp(['R_fit = ', num2str(R_fit)])
        disp(['R_predict = ', num2str(R_pre)])
        disp(['Time = ', num2str(elapsedTime)])

        X=[MSE,MAPE,MAE];
        XX=[XX;X];
        %% Display the Fianl Results
        figure(1) % origin/result
        rawdata = Targets';
        newdata = final;
        x = 1:length(rawdata);
        x_bounary = length(TrainTargets);
        plot(x,rawdata,'b-');
        hold on
        plot(x,newdata,'r--');
        hold on
        B=get(gca, 'YLim');
        plot([x_bounary, x_bounary], [B(1), B(2)], '--m');
        legend('Actual Value','Predictive Value','Location','NorthWest');
        title('Training and Prediction','FontName','Arial','FontWeight','Bold','FontSize',15);
        xlabel('Data Number','FontName','Arial','FontSize',12);
        ylabel('Value','FontName','Arial','FontSize',12);
        text('Position',[x_bounary*2/3,B(2)*5/6],'String','Training','color','r');
        text('Position',[x_bounary + 5,B(2)*5/6],'String','Prediction','color','r');
        hold off
    end
    path = ['./','ANFIS-',num2str(name(nm)),'.xls'];
    sheetName = ['DNM_' '_F'];
    xlswrite(path,XX);
end