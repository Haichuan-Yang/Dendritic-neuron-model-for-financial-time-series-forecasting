% Recording the results of ANFIS models

clear all
clc

data_index = ["DJIA-90","NASDAQCOM-90", "NDX100-90", "NIKKEI225-90", "SP500-90"];
model_index = 'ANFIS';
%==================== Controling ====================%
m = 2; % m-1 for prediction
tau = 1; % time delay
using_PSR = 1;    % 1 for true
%====================================================%
if using_PSR ==1
    m_store =   [3,3,6,4,3,5,10,3,3,7,3,4,4,3,4,10];
    tau_store = [3,2,5,2,6,2,2, 2,3,5,2,2,2,3,4,4 ];
    file_name = [model_index,'_PSR'];
else
    file_name = [model_index,'_',num2str(m),'_',num2str(tau)];
end
mkdir(['Record/',file_name])

for ii = 1:5
    
    Rec_result = [];
    Rec_error = [];
    Rec_parameter = [];
    
    load(data_index(ii))
    
    if using_PSR == 1
        m = m_store(ii);
        tau = tau_store(ii);
    end
    sheet = zeros(2,7);
    sheet(:,1) = 1:2;
    sheet = [["Rank","MSE","MAPE","MAE","RMSE","Time","Index"];sheet];
    xlswrite(['Record/',file_name,'/','_',file_name,'.xls'],sheet,'sheet1');
    
    % Method 1-3
    
    p_store = ["Grid Partitioning","FCM Clustering"];
    for ip = 1:2
        switch ip
            case 1 % Grid Partitioning
                opt = genfisOptions('GridPartition');
                opt.NumMembershipFunctions = 2;
                opt.InputMembershipFunctionType = 'trapmf';
                opt.OutputMembershipFunctionType = 'linear';
            case 2 % FCM Clustering
                opt = genfisOptions('FCMClustering','FISType','sugeno');
                opt.NumClusters = 15;
                opt.Exponent = 2;
                option.MaxNumIteration = 100;
                opt.MinImprovement = 0.00001;
                opt.Verbose = 1;
        end
        
        Main_ANFIS
        
        Rec_result = final;
        Rec_error = [MSE,MAPE,MAE,RMSE,R_fit,R_pre,elapsedTime];
        Rec_parameter = [m,tau];
        
        sup = num2str([1:M]');
        Rec_index = ["ED";"TD";"MSE";"MAPE";"MAE";"RMSE";"R_fit";"R_prediction";"Time";sup];
        f = 3; % position of MSE
        Rec_data = sortrows([Rec_parameter,Rec_error,Rec_result],f);
        Rec_avg(ip,:) = [mean(Rec_data(f)),mean(Rec_data(f+1)),mean(Rec_data(f+2)),mean(Rec_data(f+3)),mean(Rec_data(f+6)),ip];
        Rec_final = [Rec_index,Rec_data'];
        xlswrite(['Record/',file_name,'/',char(header),'_',file_name,'.xls'],Rec_final,[model_index,'_',num2str(p_store(ip))]); % Recording Path
        disp(['---------------------------------------- ',char(header),'_',model_index,'_',num2str(ip),' done ----------------------------------------']);
    end
    Rec_avg = sortrows(Rec_avg,1);
    xlswrite(['Record/',file_name,'/',char(header),'_',file_name,'.xls'],Rec_avg,'sheet1','B2:G3')
end
